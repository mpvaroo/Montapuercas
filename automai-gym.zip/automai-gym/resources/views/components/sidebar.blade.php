<aside class="sidebar">
    <div>
        <div class="brand">
            <b>AUTOMAI</b>
            GYM
        </div>

        <nav class="nav" aria-label="Menú principal">
            <a class="{{ request()->routeIs('dashboard') ? 'active' : '' }}" href="{{ route('dashboard') }}">
                <span class="ico" aria-hidden="true">
                    <svg viewBox="0 0 24 24">
                        <path d="M12 3 3 10v11h6v-7h6v7h6V10l-9-7Z" />
                    </svg>
                </span>
                Inicio
            </a>
            <a class="{{ request()->routeIs('rutinas') ? 'active' : '' }}" href="{{ route('rutinas') }}">
                <span class="ico" aria-hidden="true">
                    <svg viewBox="0 0 24 24">
                        <path d="M7 4h10v2H7V4Zm-2 4h14v12H5V8Zm2 2v8h10v-8H7Z" />
                    </svg>
                </span>
                Rutinas
            </a>
            <a class="{{ request()->routeIs('reservas') ? 'active' : '' }}" href="{{ route('reservas') }}">
                <span class="ico" aria-hidden="true">
                    <svg viewBox="0 0 24 24">
                        <path d="M6 7h12v2H6V7Zm0 4h12v2H6v-2Zm0 4h8v2H6v-2Z" />
                    </svg>
                </span>
                Reservas
            </a>
            <a class="{{ request()->routeIs('calendario') ? 'active' : '' }}" href="{{ route('calendario') }}">
                <span class="ico" aria-hidden="true">
                    <svg viewBox="0 0 24 24">
                        <path
                            d="M19 3h-1V1h-2v2H8V1H6v3H5c-1.11 0-2 .9-2 2v14c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H5V8h14v11zM7 10h5v5H7z" />
                    </svg>
                </span>
                Calendario
            </a>
            <a class="{{ request()->routeIs('progreso') ? 'active' : '' }}" href="{{ route('progreso') }}">
                <span class="ico" aria-hidden="true">
                    <svg viewBox="0 0 24 24">
                        <path d="M3.5 18.49l6-6.01 4 4L22 6.92l-1.41-1.41-7.09 7.97-4-4L2 16.99z" />
                    </svg>
                </span>
                Progreso
            </a>
            <a class="{{ request()->routeIs('ia-coach') ? 'active' : '' }}" href="{{ route('ia-coach') }}">
                <span class="ico">
                    <svg viewBox="0 0 24 24">
                        <path
                            d="M12 2a7 7 0 0 0-7 7c0 2.6 1.4 4.9 3.5 6.1V22l3-1.6 3 1.6v-6.9C17.6 13.9 19 11.6 19 9a7 7 0 0 0-7-7Zm0 2a5 5 0 1 1 0 10 5 5 0 0 1 0-10Z" />
                    </svg>
                </span>
                IA Coach
            </a>
            @if (Auth::user()->isAdmin())
                <a class="{{ request()->routeIs('panel-admin') ? 'active' : '' }}" href="{{ route('panel-admin') }}">
                    <span class="ico">
                        <svg viewBox="0 0 24 24">
                            <path
                                d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4zm0 10.99h7c-.47 4.74-3.35 8.98-7 10.23V11.99H5V6.3l7-3.11v8.8z" />
                        </svg>
                    </span>
                    Admin
                </a>
            @endif
        </nav>
    </div>

    <div class="user-block">
        <a href="{{ route('perfil') }}" class="user-link">
            <div class="user">
                <div class="avatar">
                    @php $sidebarAvatar = Auth::user()->avatar_url; @endphp
                    @if ($sidebarAvatar)
                        <img src="{{ $sidebarAvatar }}" alt="Foto de perfil"
                            onerror="this.style.display='none';this.nextElementSibling.style.display='flex';">
                        <span
                            style="display:none;width:100%;height:100%;align-items:center;justify-content:center;font-family:var(--serif);font-size:15px;font-weight:500;color:rgba(239,231,214,.86);">
                            {{ Auth::user()->initials() }}
                        </span>
                    @else
                        <span
                            style="display:flex;width:100%;height:100%;align-items:center;justify-content:center;font-family:var(--serif);font-size:15px;font-weight:500;color:rgba(239,231,214,.86);">
                            {{ Auth::user()->initials() }}
                        </span>
                    @endif
                </div>
                <div>
                    <div class="name">{{ Auth::user()->nombre_mostrado_usuario ?? 'Usuario' }}</div>
                    <div class="role">{{ Auth::user()->rol?->nombre_rol ?? 'Usuario' }}</div>
                </div>
            </div>
        </a>

        <form method="POST" action="{{ route('logout') }}" style="margin-top: 10px;">
            @csrf
            <button type="submit" class="logout-btn">
                <span class="ico">
                    <svg viewBox="0 0 24 24">
                        <path
                            d="M16 13v-2H7V8l-5 4 5 4v-3h9z m-1-9h-7v2h7v12h-7v2h7c1.1 0 2-0.9 2-2V6c0-1.1-0.9-2-2-2z" />
                    </svg>
                </span>
                Cerrar sesión
            </button>
        </form>
    </div>
</aside>

<style>
    .sidebar {
        position: fixed;
        top: 28px;
        left: 10px;
        width: 240px;
        height: calc(100vh - 56px);
        padding: 18px 14px;
        background: transparent;
        border: none;
        -webkit-backdrop-filter: none;
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        overflow: hidden;
        z-index: 100;
    }

    .brand {
        text-align: left;
        font-family: var(--sans);
        text-transform: uppercase;
        letter-spacing: .30em;
        font-weight: 700;
        font-size: 11px;
        color: var(--cream-3);
        padding: 8px 10px 14px;
    }

    .brand b {
        display: block;
        font-size: 16px;
        letter-spacing: .34em;
        color: rgba(239, 231, 214, .90);
        margin-bottom: 2px;
    }

    .nav {
        display: grid;
        gap: 6px;
        padding: 8px 8px 14px;
    }

    .nav a {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 10px 10px;
        border-radius: 14px;
        text-decoration: none;
        color: rgba(239, 231, 214, .72);
        border: 1px solid transparent;
        transition: transform .18s ease, background .18s ease, border-color .18s ease, color .18s ease;
        user-select: none;
    }

    .nav a:hover {
        transform: translateX(2px);
        background: rgba(0, 0, 0, .12);
        border-color: rgba(239, 231, 214, .14);
        color: rgba(239, 231, 214, .92);
    }

    .nav a.active {
        background:
            radial-gradient(120% 160% at 30% 0%, rgba(22, 250, 22, 0.12), transparent 35%),
            linear-gradient(180deg, rgba(0, 0, 0, .20), rgba(0, 0, 0, .12));
        border-color: rgba(239, 231, 214, .16);
        color: rgba(239, 231, 214, .95);
    }

    .ico {
        width: 18px;
        height: 18px;
        flex: 0 0 18px;
        opacity: .9;
    }

    .ico svg {
        width: 18px;
        height: 18px;
        display: block;
        fill: currentColor;
    }

    .user {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 12px 10px;
        border-radius: 16px;
        border: 1px solid rgba(239, 231, 214, .12);
        background: rgba(0, 0, 0, .10);
    }

    .avatar {
        width: 38px;
        height: 38px;
        border-radius: 999px;
        border: 1px solid rgba(239, 231, 214, .18);
        overflow: hidden;
        background: rgba(0, 0, 0, .20);
        flex: 0 0 38px;
    }

    .avatar img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        display: block;
    }

    .user .name {
        font-family: var(--sans);
        font-weight: 700;
        letter-spacing: .02em;
        color: rgba(239, 231, 214, .92);
        font-size: 14px;
        line-height: 1.15;
    }

    .user .role {
        font-size: 12px;
        color: rgba(239, 231, 214, .55);
        margin-top: 2px;
    }

    .user-link {
        text-decoration: none;
        display: block;
        transition: transform .18s ease;
    }

    .user-link:hover {
        transform: translateY(-1px);
    }

    .user-link:hover .user {
        border-color: rgba(239, 231, 214, .25);
        background: rgba(0, 0, 0, .15);
    }

    .user-block {
        display: flex;
        flex-direction: column;
        gap: 8px;
    }

    .logout-btn {
        width: 100%;
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 10px 10px;
        border-radius: 14px;
        background: rgba(255, 69, 58, 0.08);
        border: 1px solid rgba(255, 69, 58, 0.15);
        color: rgba(255, 105, 97, 0.85);
        font-family: var(--sans);
        font-size: 13px;
        font-weight: 500;
        cursor: pointer;
        transition: all .18s ease;
    }

    .logout-btn:hover {
        background: rgba(255, 69, 58, 0.12);
        border-color: rgba(255, 69, 58, 0.25);
        color: rgba(255, 105, 97, 1);
        transform: translateX(2px);
    }

    .logout-btn .ico svg {
        fill: currentColor;
    }

    @media (max-width: 900px) {
        .sidebar {
            position: relative;
            top: 0;
            height: auto;
            display: grid;
            grid-template-columns: 1fr;
            gap: 10px;
        }

        .nav {
            grid-template-columns: repeat(3, minmax(0, 1fr));
        }
    }

    @media (max-width: 640px) {
        .nav {
            grid-template-columns: 1fr;
        }
    }
</style>
