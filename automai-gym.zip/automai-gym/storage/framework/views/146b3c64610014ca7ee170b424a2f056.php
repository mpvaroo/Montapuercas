<?php
use Livewire\Component;
use App\Models\RutinaUsuario;
use App\Models\Ejercicio;
use Livewire\WithPagination;
use Livewire\Attributes\Url;
?>

<div class="grid2">
    <!-- Lista de Rutinas -->
    <div class="panel">
        <div class="panel-h"
            style="display: flex; justify-content: space-between; align-items: center; gap: 15px; flex-wrap: wrap;">
            <div style="display: flex; align-items: center; gap: 10px;">
                <strong>Mis Rutinas y Plantillas</strong>
            </div>

            <div
                style="display: flex; gap: 10px; flex-grow: 1; justify-content: flex-end; align-items: center; flex-wrap: wrap;">
                <!-- Filtros (Solo Búsqueda) -->
                <input type="text" placeholder="Buscar rutina..."
                    style="width: 140px; height: 32px; font-size: 12px; padding: 0 10px; background: rgba(255,255,255,0.05); border: 1px solid var(--cream-4); color: var(--cream);"
                    wire:model.live="routineSearch">

                <button class="mini-btn primary" wire:click="createRoutine()" style="height: 32px; padding: 0 15px;">+
                    Nueva</button>
            </div>
        </div>
        <div class="table-wrap">
            <table>
                <thead>
                    <tr>
                        <th wire:click="sortBy('nombre_rutina_usuario')" style="cursor:pointer; user-select:none;">
                            Nombre / Objetivo
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($sortField === 'nombre_rutina_usuario'): ?>
                                <span style="color:var(--cream);"><?php echo e($sortDir === 'asc' ? '↑' : '↓'); ?></span>
                            <?php else: ?>
                                <span style="color:rgba(255,255,255,0.2);">⇅</span>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </th>
                        <th wire:click="sortBy('dia_semana')" style="cursor:pointer; user-select:none;">
                            Día / Nivel
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($sortField === 'dia_semana'): ?>
                                <span style="color:var(--cream);"><?php echo e($sortDir === 'asc' ? '↑' : '↓'); ?></span>
                            <?php else: ?>
                                <span style="color:rgba(255,255,255,0.2);">⇅</span>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </th>
                        <th wire:click="sortBy('duracion_estimada_minutos')" style="cursor:pointer; user-select:none;">
                            Duración
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($sortField === 'duracion_estimada_minutos'): ?>
                                <span style="color:var(--cream);"><?php echo e($sortDir === 'asc' ? '↑' : '↓'); ?></span>
                            <?php else: ?>
                                <span style="color:rgba(255,255,255,0.2);">⇅</span>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $rutinas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rutina): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                        <tr>
                            <td>
                                <div style="font-weight:800;color:var(--cream);"><?php echo e($rutina->nombre_rutina_usuario); ?>

                                </div>
                                <div style="color:rgba(255,255,255,0.7); font-size:12px;">
                                    <?php echo e(ucfirst($rutina->objetivo_rutina_usuario)); ?></div>
                            </td>
                            <td>
                                <div
                                    style="font-weight:800;color:var(--cream);font-size:11px;text-transform:uppercase;">
                                    <?php echo e($rutina->dia_semana ?? 'Sin asignar'); ?></div>
                                <span class="pill"><?php echo e($rutina->nivel_rutina_usuario); ?></span>
                            </td>
                            <td style="color:white;"><?php echo e($rutina->duracion_estimada_minutos); ?> min</td>
                            <td>
                                <div class="actions">
                                    <button class="mini-btn warn"
                                        wire:click="editRoutine(<?php echo e($rutina->id_rutina_usuario); ?>)">Edit</button>
                                    <button class="mini-btn danger"
                                        wire:click="deleteRoutine(<?php echo e($rutina->id_rutina_usuario); ?>)"
                                        onclick="confirm('¿Seguro?') || event.stopImmediatePropagation()">X</button>
                                </div>
                            </td>
                        </tr>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Formulario (Modal) -->
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($editingRoutine): ?>
        <div class="modal-backdrop" style="display: flex;">
            <div class="modal">
                <div class="modal-head">
                    <div>
                        <h3><?php echo e($editingRoutine === 'new' ? 'Nueva Rutina Master' : 'Editar Rutina'); ?></h3>
                        <p>GESTIÓN DE PLANTILLAS</p>
                    </div>
                    <button class="modal-close" wire:click="$set('editingRoutine', null)">✕</button>
                </div>
                <form class="modal-body" wire:submit.prevent="saveRoutine" id="routineForm">
                    <div class="field">
                        <label>Nombre de la Rutina</label>
                        <input type="text" class="field-input" wire:model="nombre" required>
                    </div>
                    <div class="field">
                        <label>Objetivo Principal</label>
                        <select wire:model="objetivo" class="field-input" required>
                            <option value="">Seleccionar objetivo...</option>
                            <option value="definir">Definir</option>
                            <option value="volumen">Volumen</option>
                            <option value="rendimiento">Rendimiento</option>
                            <option value="salud">Salud</option>
                        </select>
                    </div>
                    <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 12px;">
                        <div class="field">
                            <label>Nivel Sugerido</label>
                            <select wire:model="nivel" class="field-input">
                                <option value="principiante">Principiante</option>
                                <option value="intermedio">Intermedio</option>
                                <option value="avanzado">Avanzado</option>
                            </select>
                        </div>
                        <div class="field">
                            <label>Día Programado</label>
                            <select wire:model="dia_semana" class="field-input">
                                <option value="">Sin asignar</option>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $days; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                                    <option value="<?php echo e($day); ?>"><?php echo e(ucfirst($day)); ?></option>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                            </select>
                        </div>
                        <div class="field">
                            <label>Duración (min)</label>
                            <input type="number" class="field-input" wire:model="duracion">
                        </div>
                    </div>
                    <div class="field">
                        <label>Instrucciones Generales</label>
                        <textarea class="field-input" wire:model="instrucciones" style="height: 60px;"></textarea>
                    </div>

                    <div class="divider" style="height: 1px; background: rgba(239, 231, 214, 0.1); margin: 10px 0;">
                    </div>

                    <div class="field">
                        <label>Seleccionar Ejercicios (<?php echo e(count($selectedExercises)); ?>)</label>
                        <div style="display:flex; gap:10px; margin-bottom:10px;">
                            <input type="text" class="field-input" placeholder="Filtrar ejercicios..."
                                wire:model.live="exerciseSearch" style="height: 38px;">
                            <select wire:model.live="muscleGroup" class="field-input"
                                style="width:150px; height: 38px;">
                                <option value="">Todos</option>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $muscleGroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                                    <option value="<?php echo e($mg); ?>"><?php echo e(ucfirst($mg)); ?></option>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                            </select>
                        </div>

                        <div class="exercise-grid"
                            style="max-height: 180px; overflow-y: auto; display: grid; grid-template-columns: repeat(auto-fill, minmax(130px, 1fr)); gap: 8px; padding: 4px;">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $availableExercises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ejercicio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                                <div wire:click="toggleExercise(<?php echo e($ejercicio->id_ejercicio); ?>)"
                                    class="exercise-item <?php echo e(in_array($ejercicio->id_ejercicio, $selectedExercises) ? 'selected' : ''); ?>"
                                    style="padding:10px; border:1px solid rgba(239, 231, 214, 0.1); border-radius:12px; cursor:pointer; font-size:11px; text-align:center; transition: all 0.2s; background: rgba(255, 255, 255, 0.02);">
                                    <div style="font-weight:800; color:var(--cream);">
                                        <?php echo e($ejercicio->nombre_ejercicio); ?>

                                    </div>
                                    <div class="muted"
                                        style="font-size:9px; color: rgba(239, 231, 214, 0.5); text-transform: uppercase;">
                                        <?php echo e(ucfirst($ejercicio->grupo_muscular_principal)); ?>

                                    </div>
                                </div>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                        </div>
                    </div>

                    
                </form>
                <div class="modal-foot">
                    <button type="button" class="modal-btn secondary"
                        wire:click="$set('editingRoutine', null)">CANCELAR</button>
                    <button type="submit" form="routineForm" class="modal-btn primary">GUARDAR PLANTILLA</button>
                </div>
            </div>
        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</div><?php /**PATH C:\Users\Propietario\automai-gym\Montapuercas\automai-gym\storage\framework/views/livewire/views/1931d52c.blade.php ENDPATH**/ ?>