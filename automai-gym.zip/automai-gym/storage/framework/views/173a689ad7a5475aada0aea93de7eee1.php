<?php $__env->startSection('content'); ?>
    <h1>¡Reserva Confirmada!</h1>

    <p>Hola <strong><?php echo e($reserva->user->nombre_mostrado_usuario); ?></strong>,</p>

    <p>Tu plaza para la clase de <strong><?php echo e($reserva->clase->titulo_clase); ?></strong> ya está asegurada. Estamos listos para
        darlo todo en la sesión.</p>

    <div class="panel">
        <p style="margin-top: 0;"><strong>Detalles de la sesión:</strong></p>
        <ul style="list-style: none; padding: 0; margin: 0;">
            <li style="margin-bottom: 8px;">📅 <strong>Fecha:</strong>
                <?php echo e($reserva->clase->fecha_inicio_clase->translatedFormat('l, d \d\e F')); ?></li>
            <li style="margin-bottom: 8px;">⏰ <strong>Hora:</strong> <?php echo e($reserva->clase->fecha_inicio_clase->format('H:i')); ?>

            </li>
            <li style="margin-bottom: 0;">💪 <strong>Instructor:</strong> <?php echo e($reserva->clase->instructor_clase); ?></li>
        </ul>
    </div>

    <p>Te recomendamos llegar unos minutos antes para calentar y preparar el material necesario.</p>

    <div class="button-container">
        <a href="<?php echo e(route('detalle-reserva', $reserva->clase->id_clase_gimnasio)); ?>" class="button">Ver Detalles</a>
    </div>

    <p style="font-size: 14px; text-align: center; color: rgba(239, 231, 214, 0.6);">
        Si no puedes asistir, recuerda cancelar la reserva desde tu panel para dejar el hueco a otro compañero.
    </p>

    <p style="margin-top: 40px; text-align: center;">
        ¡Nos vemos en el entrenamiento!<br>
        <strong>El equipo de AutomAI</strong>
    </p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('emails.layout', ['title' => 'Reserva Confirmada'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Propietario\automai-gym\Montapuercas\automai-gym\resources\views/emails/reservation-confirmed.blade.php ENDPATH**/ ?>