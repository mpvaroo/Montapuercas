<?php $__env->startSection('title', 'Perfil'); ?>

<?php $__env->startSection('content'); ?>
    <div class="main">
        <div>
            <header class="hero">
                <h1>Perfil.</h1>
                <p>Datos reales, objetivos y base de entrenamiento.</p>
            </header>

            <div class="section-title">
                <span class="dot" aria-hidden="true"></span>
                <span>Cuenta (usuarios)</span>
            </div>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($errors->any()): ?>
                <div
                    style="margin: 0 6px 14px; padding: 12px; background: rgba(255, 0, 0, 0.1); border: 1px solid rgba(255, 0, 0, 0.2); border-radius: var(--r); color: #ff4444; font-size: 13px;">
                    <ul>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                            <li><?php echo e($error); ?></li>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    </ul>
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            <section class="panel" aria-label="Cuenta de usuario">
                <form action="<?php echo e(route('perfil.update')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <div class="profile-row">
                        <div class="avatar-lg" style="cursor: pointer; position: relative;"
                            onclick="document.getElementById('avatarInput').click()">
                            <?php $avatarUrl = Auth::user()->avatar_url; ?>
                            <div id="avatarWrapper"
                                style="width:100%;height:100%;display:flex;align-items:center;justify-content:center;position:relative;">
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($avatarUrl): ?>
                                    <img src="<?php echo e($avatarUrl); ?>" alt="Foto de perfil" id="avatarPreview"
                                        style="width:100%;height:100%;object-fit:cover;"
                                        onerror="this.style.display='none';document.getElementById('avatarInitials').style.display='flex';">
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                <div id="avatarInitials"
                                    style="display:<?php echo e($avatarUrl ? 'none' : 'flex'); ?>;width:100%;height:100%;align-items:center;justify-content:center;font-family:var(--serif);font-size:22px;font-weight:500;color:rgba(239,231,214,.86);background:rgba(0,0,0,.10);">
                                    <?php echo e(Auth::user()->initials()); ?>

                                </div>
                            </div>
                            <div
                                style="position: absolute; bottom: 0; right: 0; background: gold; color: #000; border-radius: 50%; width: 24px; height: 24px; display: flex; align-items: center; justify-content: center; font-size: 14px;">
                                <i class="fas fa-camera"></i>
                            </div>
                        </div>
                        <input type="file" name="foto_perfil" id="avatarInput" style="display: none;"
                            accept="image/png,image/jpeg,image/jpg" onchange="previewImage(this)">
                        <div style="min-width:0;">
                            <button type="button" class="btn-small"
                                style="margin-bottom: 8px; font-size: 12px; padding: 4px 12px; background: rgba(239,231,214,.08); color: var(--gold); border: 1px solid rgba(190,145,85,.3);"
                                onclick="document.getElementById('avatarInput').click()">
                                <i class="fas fa-upload" style="margin-right: 5px;"></i> Cambiar foto
                            </button>
                            <div style="font-family:var(--serif); font-size:22px; color:rgba(239,231,214,.92); line-height:1.1;"
                                id="nombreMostrado">
                                <?php echo e(Auth::user()->nombre_mostrado_usuario ?? 'Usuario'); ?>

                            </div>
                            <div class="meta-line">
                                <span id="correoUsuario"><?php echo e(Auth::user()->correo_usuario ?? 'email@example.com'); ?></span>
                                · Estado: <span id="estadoUsuario">activo</span>
                            </div>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['foto_perfil'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div style="color: #ff4444; font-size: 11px; margin-top: 5px;"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            <div id="avatarError" style="display:none; color: #ff4444; font-size: 11px; margin-top: 5px;">
                            </div>
                            <div
                                style="font-size: 11px; color: rgba(239,231,214,.38); margin-top: 4px; letter-spacing:.06em;">
                                Solo PNG y JPG · Máx. 2 MB</div>
                        </div>
                    </div>

                    <div class="grid-2">
                        <div class="field">
                            <div class="label">Correo</div>
                            <input class="input" type="email" id="correoInput"
                                value="<?php echo e(Auth::user()->correo_usuario ?? ''); ?>" readonly />
                        </div>
                        <div class="field">
                            <div class="label">Nombre mostrado</div>
                            <input class="input" type="text" id="nombreMostradoInput"
                                value="<?php echo e(Auth::user()->nombre_mostrado_usuario ?? ''); ?>" readonly />
                        </div>
                    </div>

                    <div style="height:14px;"></div>

                    <div class="section-title" style="margin:4px 0 10px; padding:0;">
                        <span class="dot" aria-hidden="true"></span>
                        <span>Perfil</span>
                    </div>

                    <div class="grid-2">
                        <div class="field">
                            <div class="label">Nombre real</div>
                            <input class="input" id="nombreReal" type="text" placeholder="Nombre y apellidos"
                                value="<?php echo e(Auth::user()->perfil?->nombre_real_usuario ?? ''); ?>" readonly />
                        </div>
                        <div class="field">
                            <div class="label">Teléfono</div>
                            <input class="input <?php $__errorArgs = ['telefono_usuario'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> error-border <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="telefono"
                                name="telefono_usuario" type="tel" placeholder="+34 600 000 000"
                                value="<?php echo e(old('telefono_usuario', Auth::user()->perfil?->telefono_usuario ?? '')); ?>" />
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['telefono_usuario'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="error-msg"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>
                    </div>

                    <div style="height:12px;"></div>

                    <div class="grid-2">
                        <div class="field">
                            <div class="label">Fecha inicio</div>
                            <input class="input <?php $__errorArgs = ['fecha_inicio_usuario'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> error-border <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="fechaInicio"
                                name="fecha_inicio_usuario" type="date"
                                value="<?php echo e(old('fecha_inicio_usuario', Auth::user()->perfil?->fecha_inicio_usuario?->format('Y-m-d'))); ?>" />
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['fecha_inicio_usuario'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="error-msg"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>
                    </div>

                    <div style="height:14px;"></div>

                    <div class="section-title" style="margin:4px 0 10px; padding:0;">
                        <span class="dot" aria-hidden="true"></span>
                        <span>Objetivo y nivel</span>
                    </div>

                    <div class="grid-2">
                        <div class="field">
                            <div class="label">Objetivo principal</div>
                            <select class="select <?php $__errorArgs = ['objetivo_principal_usuario'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> error-border <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                id="objetivoPrincipal" name="objetivo_principal_usuario">
                                <option value="salud" <?php if(old('objetivo_principal_usuario', Auth::user()->perfil?->objetivo_principal_usuario) == 'salud'): echo 'selected'; endif; ?>>
                                    salud
                                </option>
                                <option value="definir" <?php if(old('objetivo_principal_usuario', Auth::user()->perfil?->objetivo_principal_usuario) == 'definir'): echo 'selected'; endif; ?>>
                                    definir</option>
                                <option value="volumen" <?php if(old('objetivo_principal_usuario', Auth::user()->perfil?->objetivo_principal_usuario) == 'volumen'): echo 'selected'; endif; ?>>
                                    volumen</option>
                                <option value="rendimiento" <?php if(old('objetivo_principal_usuario', Auth::user()->perfil?->objetivo_principal_usuario) == 'rendimiento'): echo 'selected'; endif; ?>>rendimiento
                                </option>
                            </select>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['objetivo_principal_usuario'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="error-msg"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>
                        <div class="field">
                            <div class="label">Nivel</div>
                            <select class="select <?php $__errorArgs = ['nivel_usuario'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> error-border <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nivelUsuario"
                                name="nivel_usuario">
                                <option value="principiante" <?php if(old('nivel_usuario', Auth::user()->perfil?->nivel_usuario) == 'principiante'): echo 'selected'; endif; ?>>
                                    principiante</option>
                                <option value="intermedio" <?php if(old('nivel_usuario', Auth::user()->perfil?->nivel_usuario) == 'intermedio'): echo 'selected'; endif; ?>>
                                    intermedio</option>
                                <option value="avanzado" <?php if(old('nivel_usuario', Auth::user()->perfil?->nivel_usuario) == 'avanzado'): echo 'selected'; endif; ?>>avanzado
                                </option>
                            </select>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['nivel_usuario'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="error-msg"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>
                    </div>

                    <div style="height:12px;"></div>

                    <div class="grid-2">
                        <div class="field">
                            <div class="label">Días por semana</div>
                            <input class="input <?php $__errorArgs = ['dias_entrenamiento_semana_usuario'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> error-border <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                id="diasSemana" name="dias_entrenamiento_semana_usuario" type="number" min="1"
                                max="7"
                                value="<?php echo e(old('dias_entrenamiento_semana_usuario', Auth::user()->perfil?->dias_entrenamiento_semana_usuario ?? '')); ?>" />
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['dias_entrenamiento_semana_usuario'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="error-msg"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>
                        <div class="field">
                            <div class="label">Duración estimada por sesión (solo UI)</div>
                            <input class="input" type="text" value="" readonly />
                        </div>
                    </div>

                    <div style="height:14px;"></div>

                    <div class="section-title" style="margin:4px 0 10px; padding:0;">
                        <span class="dot" aria-hidden="true"></span>
                        <span>Medidas base</span>
                    </div>

                    <div class="grid-2">
                        <div class="field">
                            <div class="label">Peso (kg)</div>
                            <input class="input <?php $__errorArgs = ['peso_kg_usuario'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> error-border <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="pesoKg"
                                name="peso_kg_usuario" type="number" step="0.01"
                                value="<?php echo e(old('peso_kg_usuario', Auth::user()->perfil?->peso_kg_usuario ?? '')); ?>" />
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['peso_kg_usuario'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="error-msg"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>
                        <div class="field">
                            <div class="label">Altura (cm)</div>
                            <input class="input <?php $__errorArgs = ['altura_cm_usuario'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> error-border <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="alturaCm"
                                name="altura_cm_usuario" type="number"
                                value="<?php echo e(old('altura_cm_usuario', Auth::user()->perfil?->altura_cm_usuario ?? '')); ?>" />
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['altura_cm_usuario'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="error-msg"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>
                    </div>

                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('status') === 'perfil-updated'): ?>
                        <div id="statusMsg" style="margin-top: 10px; font-size: 13px; color: #16fa16;">
                            ¡Perfil actualizado con éxito!
                        </div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                    <div class="actions justify-content-center">
                        <button class="btn" type="submit" id="saveBtn">Guardar cambios</button>
                    </div>
                </form>
            </section>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
    <style>
        .main {
            min-width: 0;
            display: grid;
            grid-template-columns: 1fr;
            max-width: 800px;
            margin: 0 auto;
            gap: 10px;
            align-content: start;
        }

        .hero {
            padding: 10px 6px 6px;
        }

        .hero h1 {
            margin: 0;
            font-family: var(--serif);
            font-weight: 500;
            font-size: clamp(34px, 3vw, 54px);
            line-height: 1.02;
            color: rgba(239, 231, 214, .90);
            text-shadow: 0 12px 40px rgba(0, 0, 0, .62);
            letter-spacing: .01em;
        }

        .hero p {
            margin: 10px 0 0;
            color: rgba(239, 231, 214, .62);
            letter-spacing: .08em;
            text-transform: uppercase;
            font-size: 12px;
        }

        .section-title {
            display: flex;
            align-items: center;
            gap: 10px;
            margin: 18px 0 10px;
            color: rgba(239, 231, 214, .78);
            font-weight: 750;
            letter-spacing: .02em;
            user-select: none;
            padding: 0 6px;
        }

        .dot {
            width: 10px;
            height: 10px;
            border-radius: 999px;
            background: rgba(22, 250, 22, .28);
            box-shadow: 0 0 0 4px rgba(22, 250, 22, .06);
            border: 1px solid rgba(239, 231, 214, .14);
        }

        .panel {
            border-radius: var(--r);
            padding: 18px;
            background:
                radial-gradient(140% 120% at 18% 10%, rgba(190, 145, 85, .16), transparent 65%),
                linear-gradient(180deg, rgba(0, 0, 0, .12), rgba(0, 0, 0, .08)),
                rgba(0, 0, 0, .12);
            border: 1px solid rgba(239, 231, 214, .12);
            box-shadow: 0 18px 52px rgba(0, 0, 0, .40);
            backdrop-filter: blur(16px) saturate(112%);
            -webkit-backdrop-filter: blur(16px) saturate(112%);
            overflow: hidden;
            margin: 0 6px 14px;
        }

        .grid-2 {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 14px;
        }

        .field {
            display: grid;
            gap: 7px;
        }

        .label {
            font-size: 12px;
            color: rgba(239, 231, 214, .58);
            letter-spacing: .10em;
            text-transform: uppercase;
        }

        .input,
        .select {
            height: 44px;
            border-radius: 14px;
            border: 1px solid rgba(239, 231, 214, .12);
            background: rgba(0, 0, 0, .12);
            color: rgba(239, 231, 214, .90);
            padding: 0 12px;
            outline: none;
            font-family: var(--sans);
            font-size: 13px;
            transition: border-color .18s ease, box-shadow .18s ease;
        }

        .select option {
            background-color: #121110;
            color: rgba(239, 231, 214, .90);
        }

        .input::placeholder {
            color: rgba(239, 231, 214, .52);
        }

        .input:focus,
        .select:focus {
            border-color: rgba(239, 231, 214, .20);
            box-shadow: 0 0 0 4px rgba(190, 145, 85, .10);
        }

        .input[readonly] {
            opacity: .75;
            cursor: not-allowed;
        }

        .profile-row {
            display: flex;
            align-items: center;
            gap: 14px;
            padding-bottom: 12px;
            border-bottom: 1px solid rgba(239, 231, 214, .10);
            margin-bottom: 14px;
        }

        .avatar-lg {
            width: 62px;
            height: 62px;
            border-radius: 999px;
            border: 1px solid rgba(239, 231, 214, .18);
            overflow: hidden;
            background: rgba(0, 0, 0, .20);
            box-shadow: 0 14px 38px rgba(0, 0, 0, .30);
            flex: 0 0 62px;
        }

        .avatar-lg img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            display: block;
        }

        .meta-line {
            color: rgba(239, 231, 214, .56);
            font-size: 12.5px;
            letter-spacing: .02em;
            margin-top: 4px;
            line-height: 1.35;
        }

        .btn {
            width: 100%;
            height: 44px;
            border-radius: 999px;
            border: 1px solid rgba(239, 231, 214, .16);
            cursor: pointer;
            background:
                radial-gradient(120% 160% at 30% 0%, var(--greenGlow), transparent 35%),
                linear-gradient(180deg, var(--greenBtn1), var(--greenBtn2));
            color: rgba(239, 231, 214, .95);
            font-family: var(--sans);
            font-weight: 800;
            letter-spacing: .06em;
            box-shadow: 0 18px 52px rgba(0, 0, 0, .50);
            transition: transform .18s ease, filter .18s ease, border-color .18s ease;
        }

        .btn:hover {
            transform: translateY(-1px);
            filter: brightness(1.06);
            border-color: rgba(239, 231, 214, .22);
        }

        .btn:active {
            transform: translateY(0);
            filter: brightness(1.02);
        }

        .btn-ghost {
            width: 100%;
            height: 44px;
            border-radius: 999px;
            border: 1px solid rgba(239, 231, 214, .12);
            background: rgba(0, 0, 0, .12);
            color: rgba(239, 231, 214, .82);
            font-family: var(--sans);
            font-weight: 800;
            letter-spacing: .06em;
            cursor: pointer;
            transition: transform .18s ease, border-color .18s ease, background .18s ease;
        }

        .btn-ghost:hover {
            transform: translateY(-1px);
            border-color: rgba(239, 231, 214, .18);
            background: rgba(0, 0, 0, .14);
        }

        .actions {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 12px;
            margin-top: 12px;
        }

        .toast {
            display: none;
            margin-top: 12px;
            color: rgba(239, 231, 214, .70);
            font-size: 12.5px;
            line-height: 1.45;
        }

        .chat {
            grid-column: 2 / 3;
            align-self: start;
            position: sticky;
            top: 28px;
            height: calc(100vh - 56px);
            display: grid;
            grid-template-rows: auto 1fr auto;
            border-radius: var(--r2);
            padding: 14px;
            background:
                radial-gradient(140% 120% at 18% 10%, rgba(190, 145, 85, .16), transparent 65%),
                linear-gradient(180deg, rgba(0, 0, 0, .16), rgba(0, 0, 0, .10)),
                rgba(0, 0, 0, .12);
            border: 1px solid rgba(239, 231, 214, .14);
            box-shadow: var(--shadow-lg);
            backdrop-filter: blur(18px) saturate(115%);
            -webkit-backdrop-filter: blur(18px) saturate(115%);
            overflow: hidden;
            min-width: 0;
        }

        .chat-head {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 10px;
            padding: 6px 6px 10px;
            border-bottom: 1px solid rgba(239, 231, 214, .10);
        }

        .chat-head .left {
            display: flex;
            align-items: center;
            gap: 10px;
            min-width: 0;
        }

        .chip {
            width: 34px;
            height: 34px;
            border-radius: 12px;
            border: 1px solid rgba(239, 231, 214, .14);
            background:
                radial-gradient(120% 160% at 30% 0%, rgba(22, 250, 22, 0.10), transparent 35%),
                rgba(0, 0, 0, .14);
            display: grid;
            place-items: center;
            color: rgba(239, 231, 214, .86);
            flex: 0 0 34px;
        }

        .chat-head h2 {
            margin: 0;
            font-weight: 900;
            letter-spacing: .02em;
            color: rgba(239, 231, 214, .92);
            font-size: 15px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .chat-head p {
            margin: 2px 0 0;
            color: rgba(239, 231, 214, .56);
            font-size: 12px;
            letter-spacing: .02em;
        }

        .kebab {
            width: 38px;
            height: 38px;
            border-radius: 12px;
            border: 1px solid rgba(239, 231, 214, .12);
            background: rgba(0, 0, 0, .12);
            color: rgba(239, 231, 214, .70);
            cursor: pointer;
            transition: transform .18s ease, border-color .18s ease;
        }

        .kebab:hover {
            transform: translateY(-1px);
            border-color: rgba(239, 231, 214, .18);
        }

        .chat-body {
            padding: 14px 6px;
            overflow: auto;
            display: flex;
            flex-direction: column;
            gap: 12px;
            scrollbar-width: thin;
            scrollbar-color: rgba(239, 231, 214, .18) transparent;
        }

        .bubble {
            max-width: 92%;
            padding: 12px 12px;
            border-radius: 16px;
            border: 1px solid rgba(239, 231, 214, .12);
            background: rgba(0, 0, 0, .14);
            color: rgba(239, 231, 214, .82);
            font-size: 13px;
            line-height: 1.4;
            letter-spacing: .01em;
            box-shadow: 0 12px 32px rgba(0, 0, 0, .24);
        }

        .bubble.ai {
            border-top-left-radius: 10px;
            background:
                radial-gradient(120% 140% at 20% 0%, rgba(190, 145, 85, .12), transparent 45%),
                rgba(0, 0, 0, .14);
        }

        .bubble.user {
            align-self: flex-end;
            border-top-right-radius: 10px;
            background:
                radial-gradient(120% 140% at 20% 0%, rgba(22, 250, 22, .10), transparent 45%),
                rgba(0, 0, 0, .16);
        }

        .chat-foot {
            padding: 10px 6px 6px;
            border-top: 1px solid rgba(239, 231, 214, .10);
            display: grid;
            grid-template-columns: 44px 1fr 44px;
            gap: 10px;
            align-items: center;
        }

        .iconbtn {
            width: 44px;
            height: 44px;
            border-radius: 14px;
            border: 1px solid rgba(239, 231, 214, .12);
            background: rgba(0, 0, 0, .12);
            color: rgba(239, 231, 214, .74);
            cursor: pointer;
            transition: transform .18s ease, border-color .18s ease;
        }

        .iconbtn:hover {
            transform: translateY(-1px);
            border-color: rgba(239, 231, 214, .18);
        }

        .chat-input {
            height: 44px;
            border-radius: 14px;
            border: 1px solid rgba(239, 231, 214, .12);
            background: rgba(0, 0, 0, .12);
            color: rgba(239, 231, 214, .90);
            padding: 0 12px;
            outline: none;
            font-family: var(--sans);
            font-size: 13px;
            transition: border-color .18s ease, box-shadow .18s ease;
        }

        .chat-input::placeholder {
            color: rgba(239, 231, 214, .52);
        }

        .chat-input:focus {
            border-color: rgba(239, 231, 214, .20);
            box-shadow: 0 0 0 4px rgba(190, 145, 85, .10);
        }

        .error-border {
            border-color: #ff4444 !important;
            box-shadow: 0 0 0 4px rgba(255, 0, 0, 0.1);
        }

        .error-msg {
            color: #ff4444;
            font-size: 11px;
            margin-top: 4px;
            font-family: var(--sans);
        }

        @media (max-width:1180px) {
            .main {
                grid-template-columns: 1fr;
            }

            .chat {
                position: relative;
                top: 0;
                height: auto;
                grid-column: 1 / -1;
            }

            .grid-2 {
                grid-template-columns: 1fr;
            }
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        const resetBtn = document.getElementById('resetBtn');

        if (resetBtn) {
            resetBtn.addEventListener('click', () => {
                location.reload();
            });
        }

        function previewImage(input) {
            if (input.files && input.files[0]) {
                const file = input.files[0];
                const allowed = ['image/png', 'image/jpeg', 'image/jpg'];

                if (!allowed.includes(file.type)) {
                    // Reset input and show error
                    input.value = '';
                    const errorEl = document.getElementById('avatarError');
                    if (errorEl) {
                        errorEl.textContent = 'Solo se permiten imágenes JPG y PNG.';
                        errorEl.style.display = 'block';
                    }
                    return;
                }

                // Hide previous error if valid
                const errorEl = document.getElementById('avatarError');
                if (errorEl) errorEl.style.display = 'none';

                const reader = new FileReader();
                reader.onload = function(e) {
                    // Show the img element with preview, hide initials
                    let img = document.getElementById('avatarPreview');
                    const initials = document.getElementById('avatarInitials');

                    if (!img) {
                        // Image element may not exist if no previous avatar — create it
                        img = document.createElement('img');
                        img.id = 'avatarPreview';
                        img.alt = 'Foto de perfil';
                        img.style.cssText = 'width:100%;height:100%;object-fit:cover;';
                        const wrapper = document.getElementById('avatarWrapper');
                        if (wrapper) wrapper.prepend(img);
                    }

                    img.src = e.target.result;
                    img.style.display = 'block';
                    if (initials) initials.style.display = 'none';
                }
                reader.readAsDataURL(file);
            }
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Propietario\automai-gym\Montapuercas\automai-gym\resources\views/perfil.blade.php ENDPATH**/ ?>