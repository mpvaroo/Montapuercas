<div>
    
    <div class="filter-bar">

        
        <div class="filter-group">
            <label class="filter-label">Desde</label>
            <input class="filter-input" type="date" wire:model.live="dateFrom" />
        </div>
        <div class="filter-group">
            <label class="filter-label">Hasta</label>
            <input class="filter-input" type="date" wire:model.live="dateTo" />
        </div>

        
        <div class="filter-group">
            <label class="filter-label">Notas</label>
            <div class="filter-select-wrap">
                <select class="filter-input filter-select" wire:model.live="filterNotes">
                    <option value="all">Todos</option>
                    <option value="with">Con nota</option>
                    <option value="without">Sin nota</option>
                </select>
            </div>
        </div>

        
        <div class="filter-group">
            <label class="filter-label">Ordenar por</label>
            <div class="filter-select-wrap">
                <select class="filter-input filter-select" wire:model.live="sortField">
                    <option value="fecha_registro">Fecha</option>
                    <option value="peso_kg_registro">Peso</option>
                    <option value="cintura_cm_registro">Cintura</option>
                    <option value="pecho_cm_registro">Pecho</option>
                    <option value="cadera_cm_registro">Cadera</option>
                </select>
            </div>
        </div>

        
        <div class="filter-group">
            <label class="filter-label">Dirección</label>
            <div class="filter-select-wrap">
                <select class="filter-input filter-select" wire:model.live="sortDir">
                    <option value="desc">↓ Mayor → Menor</option>
                    <option value="asc">↑ Menor → Mayor</option>
                </select>
            </div>
        </div>

        
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($hasActiveFilters): ?>
            <div class="filter-group" style="justify-content:flex-end;align-self:flex-end;">
                <button class="filter-clear" type="button" wire:click="clearFilters">
                    ✕ Limpiar filtros
                </button>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        
        <div wire:loading class="filter-loading">
            <span class="filter-spinner"></span>
        </div>
    </div>

    
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($records->isEmpty()): ?>
        <div class="hist-empty">No hay registros que coincidan con los filtros aplicados.</div>
    <?php else: ?>
        <div style="overflow-x:auto; margin-top:4px;">
            <table class="hist-table">
                <thead>
                    <tr>
                        <?php
                            $cols = [
                                'fecha_registro' => 'Fecha',
                                'peso_kg_registro' => 'Peso (kg)',
                                'cintura_cm_registro' => 'Cintura (cm)',
                                'pecho_cm_registro' => 'Pecho (cm)',
                                'cadera_cm_registro' => 'Cadera (cm)',
                            ];
                        ?>

                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $cols; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                            <th wire:click="sortBy('<?php echo e($field); ?>')" class="th-sortable"
                                style="cursor:pointer; user-select:none;">
                                <?php echo e($label); ?>

                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($sortField === $field): ?>
                                    <span class="sort-icon"><?php echo e($sortDir === 'asc' ? '↑' : '↓'); ?></span>
                                <?php else: ?>
                                    <span class="sort-icon-muted">⇅</span>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </th>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>

                        <th>Notas</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                        <tr>
                            <td class="td-fecha"><?php echo e($record->fecha_registro->format('Y-m-d')); ?></td>
                            <td><?php echo e($record->peso_kg_registro !== null ? number_format($record->peso_kg_registro, 2) : '—'); ?>

                            </td>
                            <td><?php echo e($record->cintura_cm_registro !== null ? number_format($record->cintura_cm_registro, 2) : '—'); ?>

                            </td>
                            <td><?php echo e($record->pecho_cm_registro !== null ? number_format($record->pecho_cm_registro, 2) : '—'); ?>

                            </td>
                            <td><?php echo e($record->cadera_cm_registro !== null ? number_format($record->cadera_cm_registro, 2) : '—'); ?>

                            </td>
                            <td class="td-nota"><?php echo e($record->notas_progreso ?? '—'); ?></td>
                            <td>
                                <a href="<?php echo e(route('progreso.detalle', $record->id_registro_progreso)); ?>"
                                    class="td-btn">VER</a>
                            </td>
                        </tr>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                </tbody>
            </table>
        </div>

        
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($records->hasPages()): ?>
            <div class="hist-pagination">
                <?php echo e($records->links()); ?>

            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <div class="hist-count">
            Mostrando <?php echo e($records->firstItem()); ?>–<?php echo e($records->lastItem()); ?> de <?php echo e($records->total()); ?> registros
        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</div>
<?php /**PATH C:\Users\Propietario\automai-gym\Montapuercas\automai-gym\resources\views/livewire/historial-progreso.blade.php ENDPATH**/ ?>