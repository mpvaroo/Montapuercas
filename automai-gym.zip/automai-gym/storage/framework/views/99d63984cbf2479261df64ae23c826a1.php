<?php
use Livewire\Component;
use App\Models\ClaseGimnasio;
use App\Models\TipoClase;
use Livewire\WithPagination;
use Livewire\Attributes\Url;
?>

<div class="grid2">
    <!-- Lista de Clases -->
    <div class="panel">
        <div class="panel-h"
            style="display: flex; justify-content: space-between; align-items: center; gap: 15px; flex-wrap: wrap;">
            <div style="display: flex; align-items: center; gap: 10px;">
                <strong>Gestión de Clases</strong>
            </div>

            <div style="display: flex; gap: 10px; flex-grow: 1; justify-content: flex-end; align-items: center;">
                <!-- Filtros (Solo Fecha y Búsqueda) -->
                <input type="date"
                    style="width: 130px; height: 32px; font-size: 12px; padding: 0 10px; background: rgba(255,255,255,0.05); border: 1px solid var(--cream-4); color: var(--cream);"
                    wire:model.live="dateFilter">

                <input type="text" placeholder="Buscar clase..."
                    style="width: 150px; height: 32px; font-size: 12px; padding: 0 10px; background: rgba(255,255,255,0.05); border: 1px solid var(--cream-4); color: var(--cream);"
                    wire:model.live="search">

                <button class="mini-btn primary" wire:click="createClass()" style="height: 32px; padding: 0 15px;">+
                    Nueva</button>
            </div>
        </div>
        <div class="table-wrap" style="max-height: 460px; overflow-y: auto;">
            <table>
                <thead style="position: sticky; top: 0; background: #000; z-index: 1;">
                    <tr>
                        <th wire:click="sortBy('titulo_clase')" style="cursor:pointer; user-select:none;">
                            Clase / Instructor
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($sortField === 'titulo_clase'): ?>
                                <span style="color:var(--cream);"><?php echo e($sortDir === 'asc' ? '↑' : '↓'); ?></span>
                            <?php else: ?>
                                <span style="color:rgba(255,255,255,0.2);">⇅</span>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </th>
                        <th wire:click="sortBy('fecha_inicio_clase')" style="cursor:pointer; user-select:none;">
                            Horario
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($sortField === 'fecha_inicio_clase'): ?>
                                <span style="color:var(--cream);"><?php echo e($sortDir === 'asc' ? '↑' : '↓'); ?></span>
                            <?php else: ?>
                                <span style="color:rgba(255,255,255,0.2);">⇅</span>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </th>
                        <th wire:click="sortBy('cupo_maximo_clase')" style="cursor:pointer; user-select:none;">
                            Cupo
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($sortField === 'cupo_maximo_clase'): ?>
                                <span style="color:var(--cream);"><?php echo e($sortDir === 'asc' ? '↑' : '↓'); ?></span>
                            <?php else: ?>
                                <span style="color:rgba(255,255,255,0.2);">⇅</span>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </th>
                        <th wire:click="sortBy('estado_clase')" style="cursor:pointer; user-select:none;">
                            Estado
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($sortField === 'estado_clase'): ?>
                                <span style="color:var(--cream);"><?php echo e($sortDir === 'asc' ? '↑' : '↓'); ?></span>
                            <?php else: ?>
                                <span style="color:rgba(255,255,255,0.2);">⇅</span>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $clases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                        <tr>
                            <td>
                                <div style="font-weight:800;color:var(--cream);"><?php echo e($clase->titulo_clase); ?></div>
                                <div class="muted"><?php echo e($clase->instructor_clase); ?>

                                    (<?php echo e($clase->tipoClase->nombre_tipo_clase); ?>)
                                </div>
                            </td>
                            <td>
                                <div style="font-size:11px; color:var(--cream);">
                                    <?php echo e($clase->fecha_inicio_clase?->format('d/m H:i')); ?>

                                </div>
                            </td>
                            <td style="color:var(--cream);">
                                <?php echo e($clase->reservas_count ?? $clase->reservas()->count()); ?>/<?php echo e($clase->cupo_maximo_clase); ?>

                            </td>
                            <td>
                                <div class="state">
                                    <span
                                        class="dot <?php echo e($clase->estado_clase === 'publicada' ? 'green' : ($clase->estado_clase === 'cancelada' ? 'red' : 'warn')); ?>"></span>
                                    <?php echo e(ucfirst($clase->estado_clase)); ?>

                                </div>
                            </td>
                            <td>
                                <div class="actions">
                                    <button class="mini-btn warn"
                                        wire:click="editClass(<?php echo e($clase->id_clase_gimnasio); ?>)">Edit</button>
                                    <button class="mini-btn danger"
                                        wire:click="deleteClass(<?php echo e($clase->id_clase_gimnasio); ?>)"
                                        onclick="confirm('¿Seguro?') || event.stopImmediatePropagation()">X</button>
                                </div>
                            </td>
                        </tr>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Formulario -->
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($editingClass): ?>
        <aside class="panel">
            <div class="panel-h"><strong><?php echo e($editingClass === 'new' ? 'Nueva Clase' : 'Editar Clase'); ?></strong></div>
            <form class="form" wire:submit.prevent="saveClass">
                <div class="field">
                    <label>Título de la Clase</label>
                    <input type="text" class="input" wire:model="titulo" required>
                </div>
                <div class="field">
                    <label>Tipo de Clase</label>
                    <select wire:model="id_tipo_clase" required>
                        <option value="">Seleccionar tipo</option>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $tipos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                            <option value="<?php echo e($tipo->id_tipo_clase); ?>"><?php echo e($tipo->nombre_tipo_clase); ?></option>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    </select>
                </div>
                <div class="field">
                    <label>Instructor</label>
                    <input type="text" class="input" wire:model="instructor" required>
                </div>
                <div class="row">
                    <div class="field">
                        <label>Fecha Inicio</label>
                        <input type="datetime-local" class="input" wire:model="inicio" required>
                    </div>
                    <div class="field">
                        <label>Fecha Fin</label>
                        <input type="datetime-local" class="input" wire:model="fin">
                    </div>
                </div>
                <div class="row">
                    <div class="field">
                        <label>Cupo Máximo</label>
                        <input type="number" class="input" wire:model="cupo" required>
                    </div>
                    <div class="field">
                        <label>Estado</label>
                        <select wire:model="estado" class="input">
                            <option value="publicada">Publicada</option>
                            <option value="borrador">Borrador</option>
                            <option value="cancelada">Cancelada</option>
                        </select>
                    </div>
                </div>
                <div class="divider"></div>
                <div class="row" style="margin-top:10px;">
                    <button type="button" class="mini-btn primary"
                        wire:click="$set('editingClass', null)">Cancelar</button>
                    <button type="submit" class="cta" style="height:40px;justify-content:center;">Guardar</button>
                </div>
            </form>
        </aside>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</div><?php /**PATH C:\Users\Propietario\automai-gym\Montapuercas\automai-gym\storage\framework/views/livewire/views/a5a03a52.blade.php ENDPATH**/ ?>