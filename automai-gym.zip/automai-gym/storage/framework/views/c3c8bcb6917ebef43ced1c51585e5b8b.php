<?php $__env->startSection('content'); ?>
    <h1>Recuperar Contraseña</h1>

    <p>Hola <strong><?php echo e($nombre); ?></strong>,</p>

    <p>Has recibido este correo porque hemos recibido una solicitud de restablecimiento de contraseña para tu cuenta en AutomAI Gym.</p>

    <div class="button-container">
        <a href="<?php echo e($url); ?>" class="button">Restablecer Contraseña</a>
    </div>

    <p style="font-size: 14px; color: rgba(239, 231, 214, 0.6);">
        Este enlace para restablecer la contraseña caducará en 60 minutos.
    </p>

    <p style="font-size: 14px; color: rgba(239, 231, 214, 0.6);">
        Si no solicitaste restablecer tu contraseña, no es necesario que realices ninguna acción.
    </p>

    <div
        style="margin-top: 30px; padding-top: 20px; border-top: 1px solid rgba(239, 231, 214, 0.1); font-size: 12px; color: rgba(239, 231, 214, 0.5);">
        Si tienes problemas con el botón, copia y pega este enlace en tu navegador:<br>
        <a href="<?php echo e($url); ?>" style="color: #466248; text-decoration: none;"><?php echo e($url); ?></a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('emails.layout', ['title' => 'Recuperar Contraseña'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Propietario\automai-gym\Montapuercas\automai-gym\resources\views/emails/reset-password.blade.php ENDPATH**/ ?>