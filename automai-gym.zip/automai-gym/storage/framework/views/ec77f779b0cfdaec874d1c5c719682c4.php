<?php
use Livewire\Component;
use App\Models\RutinaUsuario;
use App\Models\Ejercicio;
use Illuminate\Support\Facades\Auth;
?>

<div>
    <!-- Success/Error Alerts -->
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('success')): ?>
        <div
            style="background: rgba(74, 222, 128, 0.1); border: 1px solid #4ade80; color: #4ade80; padding: 12px; border-radius: 12px; margin-bottom: 20px;">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('error')): ?>
        <div
            style="background: rgba(239, 68, 68, 0.1); border: 1px solid #ef4444; color: #ef4444; padding: 12px; border-radius: 12px; margin-bottom: 20px;">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <!-- Action Bar -->
    <div class="actions">
        <button wire:click="toggleModal" class="btn-action btn-primary" style="border:none; outline:none;">
            <span>+</span> Crear Nueva Rutina
        </button>
        <a href="<?php echo e(route('calendario')); ?>" class="btn-action btn-secondary">
            <svg width="16" height="16" fill="currentColor" viewBox="0 0 24 24">
                <path
                    d="M19 4h-1V2h-2v2H8V2H6v2H5c-1.11 0-1.99.9-1.99 2L3 20a2 2 0 0 0 2 2h14c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 16H5V10h14v10zm0-12H5V6h14v2z" />
            </svg>
            Calendario de Entrenamientos
        </a>
        <div class="filter-group" style="display: flex; align-items: center; gap: 10px; margin-left: auto;">
            <span
                style="font-size: 11px; text-transform: uppercase; color: rgba(239,231,214,.5); font-weight: 700;">Mostrar:</span>
            <select wire:model.live="filter" class="input-modal"
                style="width: 160px; height: 38px; font-size: 13px; margin: 0;">
                <option value="all">Todas</option>
                <option value="usuario">Mis Rutinas</option>
                <option value="plantilla">Plantillas</option>
            </select>
        </div>
    </div>

    <!-- Routine Cards Grid -->
    <div class="routines-grid">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $routines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $rutina): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
            <div class="routine-card <?php echo e($index % 3 == 0 ? 'focus-top' : ($index % 3 == 2 ? 'full-width focus-low' : '')); ?>">
                <img class="routine-img" src="<?php echo e(asset('img/rutina-' . (($index % 3) + 1) . '.png')); ?>"
                    alt="<?php echo e($rutina->nombre_rutina_usuario); ?>">
                <div class="routine-frame"></div>
                <div class="routine-overlay">
                    <div style="<?php echo e($index % 3 == 2 ? 'max-width: 520px;' : ''); ?>">
                        <h3><?php echo e($rutina->nombre_rutina_usuario); ?></h3>
                        <div class="routine-details">
                            <div class="detail"><span class="check-ico">✓</span>
                                <?php echo e($rutina->dia_semana ? ucfirst($rutina->dia_semana) : 'Libre'); ?></div>
                            <div class="detail"><span class="check-ico">✓</span> Duración:
                                <?php echo e($rutina->duracion_estimada_minutos); ?> min
                            </div>
                            <div class="detail"><span class="check-ico">✓</span> Nivel:
                                <?php echo e(ucfirst($rutina->nivel_rutina_usuario)); ?>

                            </div>
                            <div class="detail"><span class="check-ico">👤</span> Origen:
                                <b><?php echo e($rutina->origen_rutina === 'plantilla' ? 'Plantilla' : ($rutina->origen_rutina === 'ia_coach' ? 'IA Coach' : 'Usuario')); ?></b>
                            </div>
                        </div>
                        <div class="card-actions"
                            style="<?php echo e($index % 3 == 2 ? 'grid-template-columns: 140px 140px; justify-content: start;' : ''); ?>">
                            <a href="<?php echo e(route('detalle-rutina', $rutina->id_rutina_usuario)); ?>" class="btn-card"
                                style="text-decoration:none; display:flex; align-items:center; justify-content:center;">Ver
                                Rutina</a>

                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($rutina->origen_rutina !== 'plantilla'): ?>
                                <button wire:click="deleteRoutine(<?php echo e($rutina->id_rutina_usuario); ?>)"
                                    wire:confirm="¿Estás seguro de que quieres eliminar esta rutina?" class="btn-card"
                                    style="width: 100%; margin-top: 8px; border-color: rgba(239, 68, 68, 0.3); color: #ef4444; background: rgba(239, 68, 68, 0.05);">
                                    Eliminar Rutina
                                </button>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            <div
                style="grid-column: 1 / -1; text-align: center; color: var(--cream); padding: 40px; background: rgba(0,0,0,0.2); border-radius: 12px;">
                <p>No tienes rutinas activas en esta categoría. ¡Crea una nueva o pide ayuda a tu IA Coach!</p>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>

    <!-- Modal para crear rutina -->
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($showModal): ?>
        <div class="modal-backdrop" style="display: flex;">
            <div class="modal">
                <div class="modal-head">
                    <div>
                        <h3>Diseñar nueva rutina</h3>
                        <p>GESTIÓN DE RUTINAS</p>
                    </div>
                    <button class="modal-close" wire:click="toggleModal">✕</button>
                </div>
                <form wire:submit.prevent="saveRoutine" style="display: contents;">
                    <div class="modal-body">
                        <div class="field">
                            <label class="label">Nombre de la rutina</label>
                            <input class="input-modal" type="text" wire:model="nombre" placeholder="Ej: Empuje Hipertrofia"
                                required>
                        </div>
                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
                            <div class="field">
                                <label class="label">Objetivo</label>
                                <select class="input-modal" wire:model="objetivo" required>
                                    <option value="rendimiento">Fuerza / Rendimiento</option>
                                    <option value="volumen">Hipertrofia / Volumen</option>
                                    <option value="definir">Resistencia / Definir</option>
                                    <option value="salud">Salud General</option>
                                </select>
                            </div>
                            <div class="field">
                                <label class="label">Nivel</label>
                                <select class="input-modal" wire:model="nivel" required>
                                    <option value="principiante">Principiante</option>
                                    <option value="intermedio">Intermedio</option>
                                    <option value="avanzado">Avanzado</option>
                                </select>
                            </div>
                        </div>
                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
                            <div class="field">
                                <label class="label">Duración (min)</label>
                                <input class="input-modal" type="number" wire:model="duracion">
                            </div>
                            <div class="field">
                                <label class="label">Día programado</label>
                                <select class="input-modal" wire:model="dia_semana">
                                    <option value="">Libre</option>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $days; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                                        <option value="<?php echo e($day); ?>"><?php echo e(ucfirst($day)); ?></option>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                </select>
                            </div>
                        </div>
                        <div class="field">
                            <label class="label">Instrucciones</label>
                            <textarea class="input-modal" wire:model="instrucciones" style="height:60px;"></textarea>
                        </div>

                        <div class="divider"></div>

                        <div class="field">
                            <label class="label">Seleccionar Ejercicios (<?php echo e(count($selectedExercises)); ?>)</label>
                            <div style="display:flex; gap:10px; margin-bottom:10px;">
                                <input type="text" class="input-modal" placeholder="Filtrar ejercicios..."
                                    wire:model.live="exerciseSearch" style="height:38px;">
                                <select wire:model.live="muscleGroup" class="input-modal" style="width:140px; height:38px;">
                                    <option value="">Todos</option>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $muscleGroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                                        <option value="<?php echo e($mg); ?>"><?php echo e(ucfirst($mg)); ?></option>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                </select>
                            </div>

                            <div class="exercise-grid-live"
                                style="max-height: 220px; overflow-y: auto; display: grid; grid-template-columns: repeat(auto-fill, minmax(130px, 1fr)); gap: 8px; padding: 5px;">
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $availableExercises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ex): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                                    <div wire:click="toggleExercise(<?php echo e($ex->id_ejercicio); ?>)"
                                        class="ex-item-live <?php echo e(in_array($ex->id_ejercicio, $selectedExercises) ? 'selected' : ''); ?>">
                                        <div class="ex-name"><?php echo e($ex->nombre_ejercicio); ?></div>
                                        <div class="ex-muscle"><?php echo e(ucfirst($ex->grupo_muscular_principal)); ?></div>
                                    </div>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="modal-foot">
                        <button type="button" class="modal-btn secondary" wire:click="toggleModal">CANCELAR</button>
                        <button type="submit" class="modal-btn primary">CREAR RUTINA</button>
                    </div>
                </form>
            </div>
        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    
</div><?php /**PATH C:\Users\Propietario\automai-gym\Montapuercas\automai-gym\storage\framework/views/livewire/views/71ecb0e3.blade.php ENDPATH**/ ?>