<?php

use Livewire\Component;
use App\Models\RutinaUsuario;
use App\Models\Ejercicio;

use Livewire\WithPagination;
use Livewire\Attributes\Url;

return new class extends Component {
    use WithPagination;

    public $editingRoutine = null;

    // Sorting
    #[Url(as: 'orden')]
    public $sortField = 'nombre_rutina_usuario';
    #[Url(as: 'dir')]
    public $sortDir = 'asc';

    // Filters
    public $routineSearch = '';

    public function updatingRoutineSearch()
    {
        $this->resetPage();
    }

    public function sortBy($field)
    {
        if ($this->sortField === $field) {
            $this->sortDir = $this->sortDir === 'asc' ? 'desc' : 'asc';
        } else {
            $this->sortField = $field;
            $this->sortDir = 'asc';
        }
        $this->resetPage();
    }

    // Form fields
    public $nombre = '';
    public $objetivo = '';
    public $nivel = 'intermedio';
    public $duracion = 60;
    public $instrucciones = '';
    public $selectedExercises = []; // IDs of selected exercises

    // Filters (for form exercises)
    public $exerciseSearch = '';
    public $muscleGroup = '';

    public $dia_semana = '';

    public function createRoutine()
    {
        $this->resetForm();
        $this->editingRoutine = 'new';
    }

    public function editRoutine($id)
    {
        $rutina = RutinaUsuario::with('ejercicios')->findOrFail($id);
        $this->editingRoutine = $rutina->id_rutina_usuario;
        $this->nombre = $rutina->nombre_rutina_usuario;
        $this->objetivo = $rutina->objetivo_rutina_usuario;
        $this->nivel = $rutina->nivel_rutina_usuario;
        $this->duracion = $rutina->duracion_estimada_minutos;
        $this->instrucciones = $rutina->instrucciones_rutina;
        $this->dia_semana = $rutina->dia_semana;
        $this->selectedExercises = $rutina->ejercicios->pluck('id_ejercicio')->toArray();
    }

    public function toggleExercise($id)
    {
        if (in_array($id, $this->selectedExercises)) {
            $this->selectedExercises = array_diff($this->selectedExercises, [$id]);
        } else {
            $this->selectedExercises[] = $id;
        }
    }

    public function saveRoutine()
    {
        $data = [
            'id_usuario' => Auth::id(),
            'nombre_rutina_usuario' => $this->nombre,
            'objetivo_rutina_usuario' => $this->objetivo,
            'nivel_rutina_usuario' => $this->nivel,
            'duracion_estimada_minutos' => $this->duracion,
            'instrucciones_rutina' => $this->instrucciones,
            'dia_semana' => $this->dia_semana,
            'origen_rutina' => 'plantilla',
            'rutina_activa' => true,
        ];

        if ($this->editingRoutine === 'new') {
            $rutina = RutinaUsuario::create($data);
        } else {
            $rutina = RutinaUsuario::findOrFail($this->editingRoutine);
            $rutina->update($data);
        }

        // Sync exercises
        $rutina->ejercicios()->sync($this->selectedExercises);

        $this->editingRoutine = null;
        $this->dispatch('notify', 'Rutina Master guardada.');
    }

    public function deleteRoutine($id)
    {
        RutinaUsuario::findOrFail($id)->delete();
        $this->dispatch('notify', 'Rutina eliminada.');
    }

    public function resetForm()
    {
        $this->nombre = '';
        $this->objetivo = '';
        $this->nivel = 'intermedio';
        $this->duracion = 60;
        $this->instrucciones = '';
        $this->dia_semana = '';
        $this->selectedExercises = [];
    }

    public function with(): array
    {
        // Whitelist sort fields
        $allowed = ['nombre_rutina_usuario', 'dia_semana', 'duracion_estimada_minutos'];
        $sort = in_array($this->sortField, $allowed) ? $this->sortField : 'nombre_rutina_usuario';

        return [
            'rutinas' => RutinaUsuario::where('origen_rutina', 'plantilla')
                ->where('id_usuario', Auth::id())
                ->where('nombre_rutina_usuario', 'like', '%' . $this->routineSearch . '%')
                ->orderBy($sort, $this->sortDir)
                ->paginate(10),
            'availableExercises' => Ejercicio::where('nombre_ejercicio', 'like', '%' . $this->exerciseSearch . '%')
                ->when($this->muscleGroup, function ($q) {
                    return $q->where('grupo_muscular_principal', $this->muscleGroup);
                })
                ->get(),
            'muscleGroups' => ['pecho', 'espalda', 'pierna', 'hombro', 'biceps', 'triceps', 'core', 'cardio', 'fullbody'],
            'days' => ['lunes', 'martes', 'miercoles', 'jueves', 'viernes', 'sabado', 'domingo', 'descanso'],
        ];
    }

    protected function view($data = [])
    {
        return app('view')->file('C:\Users\Propietario\automai-gym\Montapuercas\automai-gym\storage\framework/views/livewire/views/1931d52c.blade.php', $data);
    }

    public function styleModuleSrc()
    {
        return 'C:\Users\Propietario\automai-gym\Montapuercas\automai-gym\storage\framework/views/livewire/styles/1931d52c.css';
    }
};
