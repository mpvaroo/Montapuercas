<?php

use Livewire\Component;
use App\Models\RutinaUsuario;
use App\Models\Ejercicio;
use Illuminate\Support\Facades\Auth;

return new class extends Component {
    public $showModal = false;
    public $filter = 'all'; // all, usuario, plantilla

    // Form fields
    public $nombre = '';
    public $objetivo = 'salud';
    public $nivel = 'principiante';
    public $duracion = 60;
    public $instrucciones = '';
    public $dia_semana = '';
    public $selectedExercises = [];

    // Exercise search/filter
    public $exerciseSearch = '';
    public $muscleGroup = '';

    public function toggleModal()
    {
        $this->showModal = !$this->showModal;
        if ($this->showModal) {
            $this->resetForm();
        }
    }

    public function resetForm()
    {
        $this->nombre = '';
        $this->objetivo = 'salud';
        $this->nivel = 'principiante';
        $this->duracion = 60;
        $this->instrucciones = '';
        $this->dia_semana = '';
        $this->selectedExercises = [];
    }

    public function toggleExercise($id)
    {
        if (in_array($id, $this->selectedExercises)) {
            $this->selectedExercises = array_diff($this->selectedExercises, [$id]);
        } else {
            $this->selectedExercises[] = $id;
        }
    }

    public function saveRoutine()
    {
        $this->validate([
            'nombre' => 'required|string|max:140',
            'objetivo' => 'required',
            'nivel' => 'required',
        ]);

        $routine = RutinaUsuario::create([
            'id_usuario' => Auth::id(),
            'nombre_rutina_usuario' => $this->nombre,
            'objetivo_rutina_usuario' => $this->objetivo,
            'nivel_rutina_usuario' => $this->nivel,
            'duracion_estimada_minutos' => $this->duracion,
            'instrucciones_rutina' => $this->instrucciones,
            'dia_semana' => $this->dia_semana ?: null,
            'origen_rutina' => 'usuario',
            'rutina_activa' => true,
        ]);

        if (!empty($this->selectedExercises)) {
            foreach ($this->selectedExercises as $index => $exId) {
                $routine->ejercicios()->attach($exId, ['orden_en_rutina' => $index + 1]);
            }
        }

        $this->showModal = false;
        $this->dispatch('notify', 'Rutina creada correctamente.');
        return redirect()->route('detalle-rutina', $routine->id_rutina_usuario);
    }

    public function deleteRoutine($id)
    {
        $routine = RutinaUsuario::where('id_rutina_usuario', $id)->where('id_usuario', Auth::id())->firstOrFail();

        if ($routine->origen_rutina === 'plantilla') {
            $this->dispatch('error', 'No puedes eliminar una plantilla.');
            return;
        }

        $routine->delete();
        $this->dispatch('notify', 'Rutina eliminada.');
    }

    public function with(): array
    {
        $query = RutinaUsuario::query();

        if ($this->filter === 'usuario') {
            $query->where('id_usuario', Auth::id())->where('origen_rutina', 'usuario');
        } elseif ($this->filter === 'plantilla') {
            $query->where('origen_rutina', 'plantilla');
        } else {
            // 'all' - Show user's routines OR templates
            $query->where(function ($q) {
                $q->where('id_usuario', Auth::id())->orWhere('origen_rutina', 'plantilla');
            });
        }

        return [
            'routines' => $query->get(),
            'availableExercises' => Ejercicio::where('nombre_ejercicio', 'like', '%' . $this->exerciseSearch . '%')
                ->when($this->muscleGroup, function ($q) {
                    return $q->where('grupo_muscular_principal', $this->muscleGroup);
                })
                ->get(),
            'muscleGroups' => ['pecho', 'espalda', 'pierna', 'hombro', 'biceps', 'triceps', 'core', 'cardio', 'fullbody'],
            'days' => ['lunes', 'martes', 'miercoles', 'jueves', 'viernes', 'sabado', 'domingo', 'descanso'],
        ];
    }

    protected function view($data = [])
    {
        return app('view')->file('C:\Users\Propietario\automai-gym\Montapuercas\automai-gym\storage\framework/views/livewire/views/71ecb0e3.blade.php', $data);
    }

    public function styleModuleSrc()
    {
        return 'C:\Users\Propietario\automai-gym\Montapuercas\automai-gym\storage\framework/views/livewire/styles/71ecb0e3.css';
    }
};
