<?php

use Livewire\Component;
use App\Models\ClaseGimnasio;
use App\Models\TipoClase;

use Livewire\WithPagination;
use Livewire\Attributes\Url;

return new class extends Component {
    use WithPagination;

    public $editingClass = null;

    // Sorting
    #[Url(as: 'orden')]
    public $sortField = 'fecha_inicio_clase';
    #[Url(as: 'dir')]
    public $sortDir = 'desc';

    // Filters (Keep Date & Search)
    public $search = '';
    public $dateFilter = '';

    public function updatingSearch()
    {
        $this->resetPage();
    }
    public function updatingDateFilter()
    {
        $this->resetPage();
    }

    public function sortBy($field)
    {
        if ($this->sortField === $field) {
            $this->sortDir = $this->sortDir === 'asc' ? 'desc' : 'asc';
        } else {
            $this->sortField = $field;
            $this->sortDir = 'asc'; // Default asc for text, maybe desc for dates? Let's stick to asc default toggle
        }
        $this->resetPage();
    }

    // Form fields
    public $id_tipo_clase = '';
    public $titulo = '';
    public $instructor = '';
    public $inicio = '';
    public $fin = '';
    public $cupo = 20;
    public $estado = 'publicada';

    public function createClass()
    {
        $this->resetForm();
        $this->editingClass = 'new';
    }

    public function editClass($id)
    {
        $clase = ClaseGimnasio::findOrFail($id);
        $this->editingClass = $clase->id_clase_gimnasio;
        $this->id_tipo_clase = $clase->id_tipo_clase;
        $this->titulo = $clase->titulo_clase;
        $this->instructor = $clase->instructor_clase;
        $this->inicio = $clase->fecha_inicio_clase?->format('Y-m-d\TH:i');
        $this->fin = $clase->fecha_fin_clase?->format('Y-m-d\TH:i');
        $this->cupo = $clase->cupo_maximo_clase;
        $this->estado = $clase->estado_clase;
    }

    public function saveClass()
    {
        $this->validate([
            'id_tipo_clase' => 'required',
            'titulo' => 'required',
            'inicio' => 'required',
            'cupo' => 'required|numeric|min:1',
        ]);

        $inicioDate = new \DateTime($this->inicio);
        $finDate = $this->fin ? new \DateTime($this->fin) : (clone $inicioDate)->modify('+1 hour');

        $data = [
            'id_tipo_clase' => $this->id_tipo_clase,
            'titulo_clase' => $this->titulo,
            'instructor_clase' => $this->instructor ?: 'Instructor Gym',
            'fecha_inicio_clase' => $inicioDate->format('Y-m-d H:i:s'),
            'fecha_fin_clase' => $finDate->format('Y-m-d H:i:s'),
            'cupo_maximo_clase' => $this->cupo,
            'estado_clase' => $this->estado ?: 'publicada',
        ];

        if ($this->editingClass === 'new') {
            ClaseGimnasio::create($data);
        } else {
            ClaseGimnasio::findOrFail($this->editingClass)->update($data);
        }

        $this->editingClass = null;
        $this->resetPage();
        $this->dispatch('notify', 'Clase guardada correctamente.');
    }

    public function deleteClass($id)
    {
        ClaseGimnasio::findOrFail($id)->delete();
        $this->resetPage();
        $this->dispatch('notify', 'Clase eliminada.');
    }

    public function resetForm()
    {
        $this->id_tipo_clase = '';
        $this->titulo = '';
        $this->instructor = '';
        $this->inicio = '';
        $this->fin = '';
        $this->cupo = 20;
        $this->estado = 'publicada';
    }

    public function with(): array
    {
        // Whitelist sort fields
        $allowed = ['titulo_clase', 'fecha_inicio_clase', 'cupo_maximo_clase', 'estado_clase'];
        $sort = in_array($this->sortField, $allowed) ? $this->sortField : 'fecha_inicio_clase';

        return [
            'clases' => ClaseGimnasio::with('tipoClase')
                ->where(function ($q) {
                    $q->where('titulo_clase', 'like', '%' . $this->search . '%')->orWhere('instructor_clase', 'like', '%' . $this->search . '%');
                })
                ->when($this->dateFilter, function ($q) {
                    $q->whereDate('fecha_inicio_clase', $this->dateFilter);
                })
                ->orderBy($sort, $this->sortDir)
                ->paginate(10),
            'tipos' => TipoClase::all(),
        ];
    }

    protected function view($data = [])
    {
        return app('view')->file('C:\Users\Propietario\automai-gym\Montapuercas\automai-gym\storage\framework/views/livewire/views/a5a03a52.blade.php', $data);
    }
};
