<?php

use Livewire\Component;

return new class extends Component {
    public $tab = 'usuarios';

    public function setTab($tab)
    {
        $this->tab = $tab;
    }

    protected $listeners = ['tabChanged' => 'setTab'];

    protected function view($data = [])
    {
        return app('view')->file('C:\Users\Propietario\automai-gym\Montapuercas\automai-gym\storage\framework/views/livewire/views/ba7df494.blade.php', $data);
    }
};
