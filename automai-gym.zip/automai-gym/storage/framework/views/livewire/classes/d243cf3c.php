<?php

use Livewire\Component;
use App\Models\User;
use App\Models\Rol;
use Livewire\WithPagination;
use Livewire\Attributes\Url;

return new class extends Component {
    use WithPagination;

    // Sorting
    #[Url(as: 'orden')]
    public $sortField = 'nombre_mostrado_usuario';
    #[Url(as: 'dir')]
    public $sortDir = 'asc';

    public $search = '';
    public $editingUser = null;

    // Form fields
    public $nombre = '';
    public $correo = '';
    public $id_rol = '';
    public $estado = 'activo';

    public function mount($search = '')
    {
        $this->search = $search;
    }

    public function sortBy($field)
    {
        if ($this->sortField === $field) {
            $this->sortDir = $this->sortDir === 'asc' ? 'desc' : 'asc';
        } else {
            $this->sortField = $field;
            $this->sortDir = 'asc';
        }
        $this->resetPage();
    }

    public function updatingSearch()
    {
        $this->resetPage();
    }

    public function createUser()
    {
        $this->resetForm();
        $this->editingUser = 'new';
    }

    public function resetForm()
    {
        $this->nombre = '';
        $this->correo = '';
        $this->id_rol = '';
        $this->estado = 'activo';
    }

    public function editUser($id)
    {
        $user = User::with('roles')->findOrFail($id);
        $this->editingUser = $user->id_usuario;
        $this->nombre = $user->nombre_mostrado_usuario;
        $this->correo = $user->correo_usuario;
        $this->id_rol = $user->roles->first()?->id_rol ?? '';
        $this->estado = $user->estado_usuario;
    }

    public function saveUser()
    {
        if ($this->editingUser === 'new') {
            $user = User::create([
                'nombre_mostrado_usuario' => $this->nombre,
                'correo_usuario' => $this->correo,
                'estado_usuario' => $this->estado,
                'hash_contrasena_usuario' => \Illuminate\Support\Facades\Hash::make('password123'), // Default password
            ]);
        } else {
            $user = User::findOrFail($this->editingUser);
            $user->update([
                'nombre_mostrado_usuario' => $this->nombre,
                'correo_usuario' => $this->correo,
                'estado_usuario' => $this->estado,
            ]);
        }

        if ($this->id_rol) {
            $user->roles()->sync([$this->id_rol]);
        }

        $this->editingUser = null;
        $this->dispatch('notify', 'Usuario guardado correctamente.');
    }

    public function toggleStatus($id)
    {
        $user = User::findOrFail($id);
        $user->estado_usuario = $user->estado_usuario === 'activo' ? 'bloqueado' : 'activo';
        $user->save();
    }

    public function with(): array
    {
        // Whitelist sort fields
        $allowed = ['nombre_mostrado_usuario', 'correo_usuario', 'estado_usuario'];
        $sort = in_array($this->sortField, $allowed) ? $this->sortField : 'nombre_mostrado_usuario';

        return [
            'users' => User::with('roles')
                ->where(function ($query) {
                    $query->where('nombre_mostrado_usuario', 'like', '%' . $this->search . '%')->orWhere('correo_usuario', 'like', '%' . $this->search . '%');
                })
                ->orderBy($sort, $this->sortDir)
                ->paginate(10),
            'allRoles' => Rol::all(),
        ];
    }

    protected function view($data = [])
    {
        return app('view')->file('C:\Users\Propietario\automai-gym\Montapuercas\automai-gym\storage\framework/views/livewire/views/d243cf3c.blade.php', $data);
    }
};
